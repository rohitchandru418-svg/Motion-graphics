#!/usr/bin/env python3
"""
Minsky launch video, Version A (LinkedIn, ~90 s, 1920x1080, 30 fps).
SaaS motion-graphic style, no people on screen. Everything is drawn in code
(Pillow), frames are piped to ffmpeg, audio is mixed in numpy and muxed.

Quick start
  pip install pillow numpy            (optional: cairosvg for .svg logos)
  python build_minsky_A.py --preview  (960x540, 15 fps, fast check)
  python build_minsky_A.py            (final 1920x1080, 30 fps, 2x supersampled)

Useful flags
  --stills            dump 3 PNG stills per scene to out/stills (visual QA)
  --frame S4 12.5     dump one PNG: scene id and seconds inside that scene
  --scene S4          render only that scene (video only) to out/scene_S4.mp4
  --workers N  --ss 1|2  --fps 30  --width 1920

Assets (all optional; placeholders are drawn if missing)
  assets/startuptn_logo.png|svg   assets/fametn_logo.png|svg
  assets/minsky_logo_white.png|svg
  assets/fonts/Inter-Bold.ttf, Inter-Medium.ttf, (optional) a mono font
  assets/music.mp3
  vo/A_s01.mp3 ... vo/A_s09.mp3   (+ vo/A_s01.json = ElevenLabs timestamps)

Timing: every animation is keyed to words in the spoken text (T("phrase")).
With vo/*.json present the real word times are used, otherwise an estimate.
"""
import os, sys, re, json, math, random, argparse, subprocess, wave, glob
from multiprocessing import Pool
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "assets")
VO_DIR = os.path.join(HERE, "vo")
OUT = os.path.join(HERE, "out")
SR = 48000

# ----------------------------------------------------------------- design tokens
BG = (11, 15, 13)        # replace with brochure value
SURF = (20, 26, 23)
BORDER = (38, 48, 43)
GREEN = (34, 197, 94)    # replace with brochure accent
TXT = (244, 247, 245)
TXT2 = (154, 168, 160)
AMBER = (245, 158, 11)
DARK = (7, 10, 9)
GREY = (90, 100, 95)

# ----------------------------------------------------------------- fonts
def _first(paths):
    for p in paths:
        if p and os.path.exists(p):
            return p
    return None

_FD = os.path.join(ASSETS, "fonts")
FONT_PATH = {
    "b": _first([os.path.join(_FD, "Inter-Bold.ttf"), os.path.join(_FD, "Bold.ttf"),
                 "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                 "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
                 "/System/Library/Fonts/Supplemental/Arial Bold.ttf", "C:/Windows/Fonts/arialbd.ttf"]),
    "m": _first([os.path.join(_FD, "Inter-Medium.ttf"), os.path.join(_FD, "Medium.ttf"),
                 "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                 "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
                 "/System/Library/Fonts/Supplemental/Arial.ttf", "C:/Windows/Fonts/arial.ttf"]),
    "mono": _first([os.path.join(_FD, "Mono.ttf"),
                    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
                    "/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf",
                    "/System/Library/Fonts/Menlo.ttc", "C:/Windows/Fonts/consola.ttf"]),
}
_fc = {}
def F(kind, px):
    px = max(6, int(round(px)))
    k = (kind, px)
    if k not in _fc:
        p = FONT_PATH.get(kind)
        _fc[k] = ImageFont.truetype(p, px) if p else ImageFont.load_default(px)
    return _fc[k]

# ----------------------------------------------------------------- easing helpers
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def prog(u, t0, d): return clamp((u - t0) / d) if d > 0 else (1.0 if u >= t0 else 0.0)
def e_out(p): return 1 - (1 - p) ** 3
def e_expo(p): return 1.0 if p >= 1 else 1 - 2 ** (-10 * p)
def e_io(p): return p * p * (3 - 2 * p)
def e_back(p, s=0.7):
    p = p - 1
    return 1 + (s + 1) * p ** 3 + s * p ** 2
def lerp(a, b, p): return a + (b - a) * p
def rise(u, t0, d=0.6):
    """returns (alpha, dy): fade + 24 px upward slide"""
    p = e_expo(prog(u, t0, d))
    return p, (1 - p) * 24

# ----------------------------------------------------------------- drawing wrapper (coords are 1920x1080)
_GLOW = None
def glow_mask():
    global _GLOW
    if _GLOW is None:
        n = 256
        yy, xx = np.mgrid[0:n, 0:n]
        r = np.hypot(xx - n / 2, yy - n / 2) / (n / 2)
        v = np.clip(1 - r, 0, 1) ** 2.2
        _GLOW = Image.fromarray((v * 255).astype(np.uint8), "L")
    return _GLOW

_LOGO = {}
def load_logo(name):
    if name in _LOGO:
        return _LOGO[name]
    im = None
    for ext in ("png", "webp", "svg"):
        p = os.path.join(ASSETS, f"{name}.{ext}")
        if not os.path.exists(p):
            continue
        try:
            if ext == "svg":
                import cairosvg, io
                im = Image.open(io.BytesIO(cairosvg.svg2png(url=p, output_width=1400))).convert("RGBA")
            else:
                im = Image.open(p).convert("RGBA")
            break
        except Exception as e:
            print(f"[warn] could not load {p}: {e} (install cairosvg for SVG, or supply a PNG)")
    _LOGO[name] = im
    return im

class G:
    def __init__(s, im, R):
        s.im, s.R, s.d = im, R, ImageDraw.Draw(im, "RGBA")
    @staticmethod
    def col(c, a=1): return (c[0], c[1], c[2], int(255 * clamp(a)))
    def rect(s, x, y, w, h, r=0, fill=None, line=None, bw=2, a=1):
        if a <= 0: return
        R = s.R
        s.d.rounded_rectangle([x * R, y * R, (x + w) * R, (y + h) * R], radius=r * R,
                              fill=s.col(fill, a) if fill else None,
                              outline=s.col(line, a) if line else None, width=max(1, round(bw * R)))
    def circ(s, cx, cy, r, fill=None, line=None, bw=2, a=1):
        if a <= 0: return
        R = s.R
        s.d.ellipse([(cx - r) * R, (cy - r) * R, (cx + r) * R, (cy + r) * R],
                    fill=s.col(fill, a) if fill else None,
                    outline=s.col(line, a) if line else None, width=max(1, round(bw * R)))
    def line(s, pts, c=GREEN, bw=3, a=1, caps=True):
        if a <= 0: return
        R = s.R
        P = [(x * R, y * R) for x, y in pts]
        s.d.line(P, fill=s.col(c, a), width=max(1, round(bw * R)), joint="curve")
        if caps:
            r = bw * R / 2
            for x, y in (P[0], P[-1]):
                s.d.ellipse([x - r, y - r, x + r, y + r], fill=s.col(c, a))
    def poly(s, pts, fill=None, line=None, bw=2, a=1):
        R = s.R
        P = [(x * R, y * R) for x, y in pts]
        if fill: s.d.polygon(P, fill=s.col(fill, a))
        if line: s.d.line(P + [P[0]], fill=s.col(line, a), width=max(1, round(bw * R)), joint="curve")
    def text(s, t, x, y, size, c=TXT, a=1, kind="b", anchor="mm"):
        if a <= 0 or not t: return
        s.d.text((x * s.R, y * s.R), t, font=F(kind, size * s.R), fill=s.col(c, a), anchor=anchor)
    def tw(s, t, size, kind="b"):
        return s.d.textlength(t, font=F(kind, size * s.R)) / s.R
    def text2(s, parts, x, y, size, a=1, kind="b"):
        total = sum(s.tw(t, size, kind) for t, _ in parts)
        cur = x - total / 2
        for t, c in parts:
            s.text(t, cur, y, size, c, a, kind, "lm")
            cur += s.tw(t, size, kind)
    def wrap(s, t, size, maxw, kind="b"):
        lines, cur = [], ""
        for w in t.split():
            test = (cur + " " + w).strip()
            if s.tw(test, size, kind) <= maxw or not cur:
                cur = test
            else:
                lines.append(cur); cur = w
        if cur: lines.append(cur)
        return lines
    def glow(s, cx, cy, rad, a, color=GREEN):
        if a <= 0: return
        n = max(8, int(2 * rad * s.R))
        lut = [int(v * clamp(a)) for v in range(256)]
        m = glow_mask().resize((n, n), Image.BILINEAR).point(lut)
        s.im.paste(color, (int(cx * s.R - n / 2), int(cy * s.R - n / 2)), m)
    def logo(s, name, cx, cy, w, a=1, label=None):
        im = load_logo(name)
        if a <= 0: return
        if im is None:   # placeholder wordmark
            s.text(label or name, cx, cy, w * 0.16, TXT, a)
            return
        wpx = max(2, int(w * s.R)); hpx = max(2, int(wpx * im.height / im.width))
        r = im.resize((wpx, hpx), Image.LANCZOS)
        mask = r.getchannel("A").point([int(v * clamp(a)) for v in range(256)])
        s.im.paste(r.convert("RGB"), (int(cx * s.R - wpx / 2), int(cy * s.R - hpx / 2)), mask)

def card(g, x, y, w, h, a=1, line=BORDER, fill=SURF, r=16, bw=1.5):
    g.rect(x, y + 14, w, h, r, fill=(0, 0, 0), a=0.22 * a)
    g.rect(x, y, w, h, r, fill=fill, line=line, bw=bw, a=a)

def chip(g, cx, cy, w, h, label, icon=None, a=1, lit=False, size=36):
    g.rect(cx - w / 2, cy - h / 2, w, h, h / 2, fill=GREEN if lit else SURF, line=GREEN if lit else BORDER,
           bw=2, a=a * (0.16 if lit else 1)) if False else None
    g.rect(cx - w / 2, cy - h / 2, w, h, h / 2, fill=SURF, line=GREEN if lit else BORDER, bw=3 if lit else 1.5, a=a)
    if lit: g.rect(cx - w / 2, cy - h / 2, w, h, h / 2, fill=GREEN, a=0.12 * a)
    tx = cx
    if icon:
        icon_draw(g, icon, cx - w / 2 + h * 0.62, cy, h * 0.5, GREEN if lit else TXT2, a)
        tx = cx + h * 0.3
    g.text(label, tx, cy, size, TXT, a)

def icon_draw(g, name, cx, cy, s, c=TXT, a=1):
    bw = max(2.5, s * 0.075)
    if name == "doc":
        g.rect(cx - .3 * s, cy - .42 * s, .6 * s, .84 * s, s * .08, line=c, bw=bw, a=a)
        for i in range(3):
            g.line([(cx - .17 * s, cy - .15 * s + i * .17 * s), (cx + .17 * s - (i == 2) * .12 * s, cy - .15 * s + i * .17 * s)], c, bw * .8, a)
    elif name == "magnifier":
        g.circ(cx - .08 * s, cy - .08 * s, .27 * s, line=c, bw=bw, a=a)
        g.line([(cx + .12 * s, cy + .12 * s), (cx + .38 * s, cy + .38 * s)], c, bw * 1.2, a)
    elif name == "bars":
        for i, hh in enumerate((.35, .6, .85)):
            g.rect(cx - .36 * s + i * .26 * s, cy + .4 * s - hh * s, .18 * s, hh * s, s * .04, fill=c, a=a)
    elif name == "arrow":
        g.line([(cx - .4 * s, cy), (cx + .35 * s, cy)], c, bw, a)
        g.line([(cx + .08 * s, cy - .27 * s), (cx + .38 * s, cy), (cx + .08 * s, cy + .27 * s)], c, bw, a)
    elif name == "loop":
        R = s * .33
        g.d.arc([(cx - R) * g.R, (cy - R) * g.R, (cx + R) * g.R, (cy + R) * g.R], 30, 320,
                fill=g.col(c, a), width=max(1, round(bw * g.R)))
        g.poly([(cx + .22 * s, cy - .36 * s), (cx + .42 * s, cy - .12 * s), (cx + .1 * s, cy - .1 * s)], fill=c, a=a)
    elif name == "mail":
        g.rect(cx - .4 * s, cy - .27 * s, .8 * s, .54 * s, s * .06, line=c, bw=bw, a=a)
        g.line([(cx - .38 * s, cy - .22 * s), (cx, cy + .06 * s), (cx + .38 * s, cy - .22 * s)], c, bw * .8, a)
    elif name == "stack":
        for i in range(3):
            g.rect(cx - .36 * s, cy - .36 * s + i * .22 * s, .72 * s, .22 * s, s * .05, fill=SURF, line=c, bw=bw * .8, a=a)
    elif name == "eye":
        g.d.ellipse([(cx - .42 * s) * g.R, (cy - .24 * s) * g.R, (cx + .42 * s) * g.R, (cy + .24 * s) * g.R],
                    outline=g.col(c, a), width=max(1, round(bw * g.R)))
        g.circ(cx, cy, .12 * s, fill=c, a=a)
    elif name == "clip":
        g.rect(cx - .3 * s, cy - .4 * s, .6 * s, .8 * s, s * .07, line=c, bw=bw, a=a)
        g.line([(cx - .14 * s, cy + .02 * s), (cx - .03 * s, cy + .14 * s), (cx + .17 * s, cy - .12 * s)], c, bw, a)
    elif name == "shield":
        g.poly([(cx, cy - .5 * s), (cx + .4 * s, cy - .35 * s), (cx + .4 * s, cy + .05 * s), (cx, cy + .5 * s),
                (cx - .4 * s, cy + .05 * s), (cx - .4 * s, cy - .35 * s)], line=c, bw=bw * 1.3, a=a)
        g.line([(cx - .17 * s, cy), (cx - .04 * s, cy + .14 * s), (cx + .2 * s, cy - .14 * s)], c, bw * 1.3, a)
    elif name == "check":
        g.line([(cx - .3 * s, cy + .02 * s), (cx - .08 * s, cy + .24 * s), (cx + .32 * s, cy - .2 * s)], c, bw * 1.2, a)
    elif name == "calendar":
        g.rect(cx - .4 * s, cy - .36 * s, .8 * s, .76 * s, s * .08, line=c, bw=bw, a=a)
        g.line([(cx - .4 * s, cy - .1 * s), (cx + .4 * s, cy - .1 * s)], c, bw, a)
        g.line([(cx - .2 * s, cy - .46 * s), (cx - .2 * s, cy - .28 * s)], c, bw, a)
        g.line([(cx + .2 * s, cy - .46 * s), (cx + .2 * s, cy - .28 * s)], c, bw, a)
    elif name == "person":
        g.circ(cx, cy - .17 * s, .17 * s, fill=c, a=a)
        g.d.pieslice([(cx - .3 * s) * g.R, (cy + .02 * s) * g.R, (cx + .3 * s) * g.R, (cy + .62 * s) * g.R],
                     180, 360, fill=g.col(c, a))
    elif name == "chat":
        g.rect(cx - .4 * s, cy - .3 * s, .8 * s, .52 * s, s * .12, fill=c, a=a)
        g.poly([(cx - .22 * s, cy + .2 * s), (cx - .3 * s, cy + .42 * s), (cx - .02 * s, cy + .2 * s)], fill=c, a=a)

def tick_circle(g, cx, cy, r, a=1, p=1.0):
    g.circ(cx, cy, r * p, fill=GREEN, a=a)
    if p > .6: icon_draw(g, "check", cx, cy, r * 1.4 * p, BG, a)

# ----------------------------------------------------------------- background
_BGC = {}
def make_bg(t, R):
    key = R
    if key not in _BGC:
        w, h = int(round(1920 * R)), int(round(1080 * R))
        sp = int(round(48 * R))
        gm = Image.new("L", (w + sp, h + sp), 0)
        gd = ImageDraw.Draw(gm)
        rr = max(1, int(1.6 * R))
        for x in range(0, w + sp, sp):
            for y in range(0, h + sp, sp):
                gd.ellipse([x - rr, y - rr, x + rr, y + rr], fill=14)
        _BGC[key] = (Image.new("RGB", (w, h), BG), gm, sp)
    base, gm, sp = _BGC[key]
    im = base.copy()
    ox = int((t * 8 * R) % sp); oy = int((t * 4 * R) % sp)
    im.paste((255, 255, 255), (0, 0), gm.crop((ox, oy, ox + im.width, oy + im.height)))
    G(im, R).glow(960, 560, 760, 0.05 + 0.02 * math.sin(t * 2.1))
    return im

# ----------------------------------------------------------------- scenes
def app_card(g, cx, cy, a):
    g.rect(cx - 130, cy - 170, 260, 340, 14, fill=SURF, line=BORDER, bw=1.5, a=a)
    g.rect(cx - 106, cy - 146, 120, 16, 6, fill=TXT, a=a * .35)
    for i in range(3):
        g.rect(cx - 106, cy - 100 + i * 34, 212 - (i == 2) * 80, 12, 5, fill=TXT2, a=a * .5)
    g.rect(cx + 50, cy + 128, 62, 26, 7, fill=AMBER, a=a * .85)
    g.text("PDF", cx + 81, cy + 141, 17, BG, a)

def S1(g, u, T, sc):
    rnd = random.Random(7)
    for i in range(40):
        x = rnd.uniform(140, 1780); yf = rnd.uniform(420, 1040)
        p = e_out(prog(u, 0.4 + i * 0.11, 0.9))
        if p > 0:
            app_card(g, x, lerp(-220, yf, p), 0.24 * min(1, p * 3))
    g.glow(960, 480, 620, 0.10 + 0.04 * math.sin(u * 2.1))
    pl = prog(u, 0, 0.4)
    if u < 1.0:
        g.line([(880, 520), (880 + 160 * e_out(pl), 520)], GREEN, 3, 1 - prog(u, 0.6, 0.4))
    pc = e_out(prog(u, 0.4, 2.4))
    v = int(round(10000 * pc))
    s = f"{v:,}"
    g.text(s, 960, 470, 180, GREEN, prog(u, 0.4, 0.2))
    if pc >= 1:
        g.text("+", 960 + g.tw(s, 180) / 2 + 6, 470, 180, GREEN, prog(u, 2.8, 0.2), "b", "lm")
    a, dy = rise(u, 3.0)
    g.text("applications. All read by hand.", 960, 620 + dy, 56, TXT2, a, "m")

def S2(g, u, T, sc):
    a, dy = rise(u, 0.0, 0.5)
    out = e_io(prog(u, sc["dur"] - 0.8, 0.5))
    a *= 1 - 0.7 * out
    jr = random.Random(int(u * 7.5))
    jx, jy = (jr.uniform(-1, 1), jr.uniform(-1, 1)) if u > 1 else (0, 0)
    card(g, 120 - out * 40, 200 + dy, 780, 560, a)
    card(g, 1020 + out * 40, 200 + dy, 780, 560, a)
    g.text("Email", 510 - out * 40, 245 + dy, 40, TXT2, a, "m")
    g.text("Spreadsheets", 1410 + out * 40, 245 + dy, 40, TXT2, a, "m")
    av = [(330, 460), (690, 460), (510, 650)]
    for i, (x, y) in enumerate(av):
        g.circ(x + jx - out * 40, y + jy + dy, 48, fill=BORDER, line=GREY, a=a)
        g.text("ARK"[i], x + jx - out * 40, y + jy + dy, 40, TXT2, a)
    if u > 0.5:
        for i in range(6):
            A, B = av[i % 3], av[(i + 1 + i // 3) % 3]
            s = (u * 0.5 + i / 6) % 1
            q = e_io(s)
            nx, ny = -(B[1] - A[1]), (B[0] - A[0]); n = math.hypot(nx, ny) or 1
            off = math.sin(math.pi * s) * 70
            x = lerp(A[0], B[0], q) + nx / n * off; y = lerp(A[1], B[1], q) + ny / n * off
            icon_draw(g, "mail", x - out * 40, y + dy, 58, AMBER, a * 0.95)
    rnd = random.Random(3)
    amber_cells = set(rnd.sample(range(48), 7))
    gx, gy = 1050 + out * 40, 300 + dy
    for k in range(48):
        r_, c_ = divmod(k, 8)
        pk = prog(u, 0.5 + k * 0.08, 0.2)
        x, y = gx + c_ * 90 + jx, gy + r_ * 70 + jy
        g.rect(x, y, 88, 68, 6, line=BORDER, bw=1, a=a)
        if pk > 0:
            hot = k in amber_cells and u > 3.0
            g.text(str(rnd.randint(10, 999)), x + 44, y + 34, 26, AMBER if hot else TXT2, a * pk, "mono")
            if hot:
                g.rect(x, y, 88, 68, 6, line=AMBER, bw=2.5, a=a)
                g.circ(x + 76, y + 12, 12, fill=AMBER, a=a)
                g.text("?", x + 76, y + 12, 18, BG, a)
    t5 = T("scored on", 3.0) - 0.2
    a5, d5 = rise(u, t5)
    g.text("Slow. Scattered. Hard to audit.", 960, 835 + d5, 52, AMBER, a5 * (1 - out))

def S3(g, u, T, sc):
    ps = prog(u, 0, 0.4)
    if ps < 1:
        x = 1920 * e_out(ps)
        g.line([(x, 0), (x, 1080)], GREEN, 5, 1 - ps * 0.6, False)
        g.glow(x, 540, 260, 0.2 * (1 - ps))
    tsh = T("so we didn't", 4.0) - 0.3
    pr = e_io(prog(u, tsh, 0.6))
    a, dy = rise(u, 0.4)
    cx, cy = lerp(960, 230, pr), lerp(480, 110, pr)
    w, h = lerp(460, 220, pr), lerp(260, 100, pr)
    g.glow(960, 480, 520, 0.14 * a * (1 - pr))
    card(g, cx - w / 2, cy - h / 2 + dy, w, h, a)
    g.logo("startuptn_logo", cx, cy + dy, lerp(360, 170, pr), a, "StartupTN")
    ah, dh = rise(u, tsh + 0.4)
    g.text2([("Not a chatbot. ", TXT), ("A rebuilt workflow.", GREEN)], 960, 190 + dh, 84, ah)
    ac, dc = rise(u, tsh + 0.9)
    card(g, 180, 300 + dc, 720, 430, ac)
    card(g, 1020, 300 + dc, 720, 430, ac)
    g.text("Bolted-on chatbot", 540, 350 + dc, 40, TXT2, ac, "m")
    g.text("Rebuilt workflow", 1380, 350 + dc, 40, TXT, ac, "m")
    tl = T("bolt a chatbot", tsh + 2.0)
    dim = 1 - 0.6 * e_io(prog(u, tl + 0.5, 0.4))
    g.rect(380, 470 + dc, 320, 170, 18, fill=BORDER, line=GREY, a=ac * dim)
    icon_draw(g, "chat", 600, 440 + dc, 90, AMBER, ac * dim)
    for i in range(3):
        g.line([(410, 510 + i * 40 + dc), (650 - i * 50, 510 + i * 40 + dc)], GREY, 6, ac * dim)
    ps2 = e_out(prog(u, tl + 0.2, 0.4))
    if ps2 > 0:
        g.line([(200, 530 + dc), (200 + 680 * ps2, 530 + dc)], GREEN, 6, ac)
    tr = T("we rebuilt", tsh + 3.0)
    for i in range(4):
        pb = e_back(prog(u, tr + i * 0.3, 0.35))
        x = 1070 + i * 170
        if pb > 0:
            if i:
                g.line([(x - 30, 520 + dc), (x, 520 + dc)], GREEN, 4, ac * prog(u, tr + i * 0.3, 0.2))
            g.rect(x, 470 + dc, 120, 100, 14, fill=SURF, line=GREEN, bw=3, a=ac * clamp(pb))
            icon_draw(g, ["doc", "magnifier", "bars", "arrow"][i], x + 60, 520 + dc, 56, GREEN, ac * clamp(pb))
    pt = prog(u, tr + 1.4, 0.35)
    if pt > 0: tick_circle(g, 1380, 650 + dc, 34, ac, e_back(pt))

def S4(g, u, T, sc):
    n = [T("reads the", 1.0), T("checks the", 2.6), T("ranks every", 4.6)]
    n += [n[2] + 1.2, n[2] + 2.0]
    tcom = T("committee still", 9.0)
    thead = T("ai ranks. people", 11.5) - 0.2
    tlog = T("every step", 14.0) - 0.6
    base = 1 - 0.7 * e_io(prog(u, thead, 0.5))
    base *= 1 - e_io(prog(u, tlog, 0.4))
    titles = ["Understand", "Reason", "Decide", "Act", "Learn"]
    descs = ["Reads the pitch deck", "Checks GST and tax records", "Ranks every startup", "Sends the shortlist", "Improves with feedback"]
    icons = ["doc", "magnifier", "bars", "arrow", "loop"]
    for i in range(5):
        x = 180 + i * 320
        a, dy = rise(u, 0.1 + i * 0.12)
        a *= base
        li = prog(u, n[i], 0.3)
        g.rect(x, 190 + 14 + dy, 280, 200, 16, fill=(0, 0, 0), a=0.2 * a)
        g.rect(x, 190 + dy, 280, 200, 16, fill=SURF, line=GREEN if li > 0 else BORDER, bw=3 if li > 0 else 1.5, a=a)
        if li > 0: g.rect(x, 190 + dy, 280, 200, 16, fill=GREEN, a=0.16 * li * a)
        icon_draw(g, icons[i], x + 140, 244 + dy, 56, GREEN if li > .5 else TXT2, a)
        g.text(titles[i], x + 140, 300 + dy, 36, TXT, a)
        for j, ln in enumerate(g.wrap(descs[i], 24, 236, "m")):
            g.text(ln, x + 140, 338 + j * 28 + dy, 24, TXT2, a, "m")
        if i:
            xa, xb = x - 40, x
            g.line([(xa, 290 + dy), (xb, 290 + dy)], BORDER, 3, a)
            pl = e_out(prog(u, n[i] - 0.35, 0.35))
            if pl > 0:
                g.line([(xa, 290 + dy), (xa + 40 * pl, 290 + dy)], GREEN, 4, a)
                if pl < 1: g.circ(xa + 40 * pl, 290 + dy, 8, fill=GREEN, a=a)
    # ranked list panel
    pp = T("ranks every", 4.0) - 0.2
    a, dy = rise(u, pp, 0.7)
    a *= base
    if a > 0:
        card(g, 360, 430 + dy, 1200, 400, a)
        rows = [("Greenleaf Agritech", 92), ("MedLoop", 88), ("Vaayu Labs", 85), ("KrishiOne", 81), ("Tamil Robotics", 79)]
        for i, (nm, sc_) in enumerate(rows):
            y = 475 + i * 66 + dy
            pr = e_out(prog(u, pp + 0.3 + i * 0.12, 0.5))
            g.text(str(i + 1), 410, y, 30, TXT2, a * pr, "mono", "lm")
            g.text(nm, 460, y, 30, TXT, a * pr, "b", "lm")
            g.rect(850, y - 8, 380, 16, 8, fill=BORDER, a=a * pr)
            g.rect(850, y - 8, 380 * sc_ / 100 * pr, 16, 8, fill=GREEN, a=a * pr)
            g.text(str(int(sc_ * pr)), 1260, y, 32, GREEN, a * pr, "b", "lm")
            g.rect(1370, y - 20, 160, 40, 20, line=TXT2, bw=1.5, a=a * pr * .8)
            g.text("Evidence", 1450, y, 22, TXT2, a * pr, "m")
        g.text("Sample data", 1536, 810 + dy, 22, TXT2, a * .8, "m", "rm")
        pc = prog(u, tcom, 0.5)
        if pc > 0:
            g.rect(356, 426 + dy, 1208, 408, 18, line=GREEN, bw=4, a=pc * a)
            chip(g, 1440, 430 + dy, 250, 62, "Committee", "person", pc * a, True, 30)
            if 0 < prog(u, tcom + .5, .4) < 1: pass
    # headline
    ph = prog(u, thead, 0.9)
    pm = e_io(prog(u, tlog, 0.6))
    if ph > 0:
        txt = "AI ranks. People decide."
        k = int(len(txt) * ph + 0.5)
        sz = lerp(120, 60, pm); yy = lerp(540, 150, pm)
        full = g.tw(txt, sz)
        part = txt[:k]
        x0 = 960 - full / 2
        g.text(part.replace("People decide.", "") if k < 9 else part[:9], x0, yy, sz, TXT, 1, "b", "lm")
        if k > 9:
            g.text(part[9:], x0 + g.tw(txt[:9], sz), yy, sz, GREEN, 1, "b", "lm")
    pl_ = e_expo(prog(u, tlog + 0.3, 0.6))
    if pl_ > 0:
        card(g, 480, 260 + (1 - pl_) * 24, 960, 430, pl_)
        g.text("Every step is logged", 960, 310, 36, TXT2, pl_, "m")
        logs = ["10:42  Deck parsed", "10:42  GST verified", "10:43  Score generated", "10:51  Committee approved"]
        for i, s in enumerate(logs):
            pa = prog(u, tlog + 0.9 + i * 0.7, 0.35)
            g.text(s, 540, 380 + i * 72, 32, TXT, pl_ * pa, "mono", "lm")
            if i == 3 and pa > 0: tick_circle(g, 1370, 380 + i * 72, 18, pa * pl_, e_back(pa))

def S5(g, u, T, sc):
    t80 = T("eighty", 2.0); t30 = T("thirty days", t80 + 2.0)
    tc = t80 - 0.5
    ex = e_io(prog(u, tc - 0.4, 0.4))
    a, dy = rise(u, 0.2)
    a *= 1 - ex
    sh = ex * 900
    dv = e_out(prog(u, 0.6, 0.8))
    dim = 1 - 0.65 * e_io(prog(u, 1.4, 0.4))
    card(g, 180 - sh, 250 + dy, 720, 500, a * (dim if dv >= 1 else 1))
    card(g, 1020 + sh, 250 + dy, 720, 500, a)
    g.text("Before", 540 - sh, 300 + dy, 44, AMBER, a * dim)
    g.text("After", 1380 + sh, 300 + dy, 44, GREEN, a)
    rnd = random.Random(5)
    for r_ in range(4):
        for c_ in range(5):
            hot = rnd.random() < .3
            g.rect(240 - sh + c_ * 120, 350 + r_ * 85 + dy, 108, 72, 8, line=AMBER if hot else BORDER, bw=2, a=a * dim)
    for i in range(5):
        wv = 520 - i * 70
        g.rect(1070 + sh, 360 + i * 68 + dy, wv, 40, 10, fill=GREEN if i == 0 else BORDER, a=a * (1 if i == 0 else .9))
    if 0 < dv:
        x = lerp(180, 960, dv)
        g.line([(x, 250), (x, 750)], GREEN, 4, a * (1 - prog(u, 1.4, .3)))
    # stat cards
    ac, dc = rise(u, tc + 0.1)
    card(g, 180, 290 + dc, 700, 490, ac)
    card(g, 1040, 290 + dc, 700, 490, ac)
    p80 = e_out(prog(u, t80, 1.2))
    g.text(f"{int(round(80 * p80))}%", 530, 470 + dc, 200, GREEN, ac * prog(u, t80, .2))
    g.text("less manual screening", 530, 640 + dc, 44, TXT, ac * prog(u, t80 + .5, .4), "m")
    p30 = e_out(prog(u, t30, 1.2))
    s30 = str(int(round(30 * p30)))
    wd = g.tw("30", 200) + 24 + g.tw("days", 70)
    xs = 1390 - wd / 2
    flip = int(u * 3.2) % 3 if 0 < p30 < 1 else 0
    icon_draw(g, "calendar", 1390, 365 + dc, 90, GREEN, ac * prog(u, t30 - .2, .3))
    g.text(s30, xs, 500 + dc, 200, GREEN, ac * prog(u, t30, .2), "b", "lm")
    g.text("days", xs + g.tw("30", 200) + 24, 530 + dc, 70, TXT2, ac * prog(u, t30, .2), "b", "lm")
    g.text("faster", 1390, 650 + dc, 44, TXT, ac * prog(u, t30 + .5, .4), "m")
    g.text("StartupTN screening process.", 960, 840, 24, TXT2, prog(u, t30 + 1.4, .5) * .9, "m")

def _s6_lines():
    rnd = random.Random(11)
    p = list(range(12)); rnd.shuffle(p)
    q = list(range(12)); rnd.shuffle(q)
    pairs = [(i, p[i]) for i in range(12)] + [(i, q[i]) for i in range(0, 12, 2)]
    t, times = 0.9, []
    for k in range(len(pairs)):
        times.append(t); t += max(0.07, 0.3 - 0.02 * k)
    return pairs, times

def S6(g, u, T, sc):
    tm = T("ten thousand", 3.5); tmt = T("more than three", 6.5)
    a, dy = rise(u, 0.1)
    card(g, 120, 50 + dy, 300, 110, a)
    g.logo("fametn_logo", 270, 105 + dy, 230, a, "FaMeTN")
    card(g, 120, 190 + dy, 1100, 640, a)
    tg = max(tmt - 1.3, 4.6)
    pg = e_io(prog(u, tg, 0.6))
    na = a * (1 - pg)
    g.text("Buyers", 300, 245 + dy, 32, TXT2, na, "m"); g.text("Sellers", 1040, 245 + dy, 32, TXT2, na, "m")
    ys = [310 + i * 40 for i in range(12)]
    pairs, times = _s6_lines()
    for k, (i, j) in enumerate(pairs):
        pl = e_out(prog(u, times[k], 0.45))
        if pl > 0:
            g.line([(322, ys[i] + dy), (322 + 696 * pl, lerp(ys[i], ys[j], pl) + dy)], GREEN, 2.5, na * .8)
    for side, x in ((0, 300), (1, 1040)):
        for i in range(12):
            pop = 1.0
            for k, (bi, bj) in enumerate(pairs):
                idx = bi if side == 0 else bj
                if idx == i:
                    pk = prog(u, times[k] + .35, .25)
                    pop = max(pop, 1 + .3 * math.sin(math.pi * pk) if 0 < pk < 1 else 1)
            g.circ(x, ys[i] + dy, 14 * pop, fill=SURF, line=GREEN, bw=2.5, a=na)
    if pg > 0:
        cols = ["Table 1", "Table 2", "Table 3", "Table 4"]
        rows = ["10:00", "11:00", "12:00", "13:00"]
        for c_ in range(4):
            g.text(cols[c_], 270 + c_ * 216 + 100, 335 + dy, 26, TXT2, pg, "m")
        rnd = random.Random(2)
        for r_ in range(4):
            g.text(rows[r_], 255, 405 + r_ * 84 + dy, 24, TXT2, pg, "m", "rm")
            for c_ in range(4):
                x, y = 270 + c_ * 216, 370 + r_ * 84
                g.rect(x, y + dy, 200, 70, 10, line=BORDER, bw=1.5, a=pg)
                if rnd.random() < .7:
                    pf = prog(u, tg + 0.5 + (r_ * 4 + c_) * 0.1, 0.25)
                    g.rect(x + 6, y + 6 + dy, 188, 58, 8, fill=GREEN, a=.28 * pf * pg)
                    g.rect(x + 6, y + 6 + dy, 188, 58, 8, line=GREEN, bw=1.5, a=pf * pg)
    p1 = e_out(prog(u, tm, 1.2)); a1, d1 = rise(u, tm, 0.4)
    g.text(f"{int(round(10000 * p1)):,}+", 1560, 400 + d1, 120, GREEN, a1)
    g.text("matches", 1560, 495 + d1, 44, TXT, a1, "m")
    p2 = e_out(prog(u, tmt, 1.2)); a2, d2 = rise(u, tmt, 0.4)
    g.text(f"{int(round(3500 * p2)):,}+", 1560, 650 + d2, 120, GREEN, a2)
    g.text("meetings", 1560, 745 + d2, 44, TXT, a2, "m")

def S7(g, u, T, sc):
    tc = [T("huge volumes", 2.6), T("public scrutiny", 3.4), T("audits", 4.2)]
    tmg = T("if it holds", 5.0)
    pm = e_io(prog(u, tmg, 0.7))
    labels = ["Huge volumes", "Public scrutiny", "Audits"]; icons = ["stack", "eye", "clip"]
    for i in range(3):
        pdrop = e_back(prog(u, tc[i], 0.5))
        if pdrop <= 0: continue
        cy = lerp(330 + i * 120, 440, pm)
        w = lerp(640, 120, pm)
        a = clamp(pdrop) * (1 - pm)
        chip(g, 960, cy - (1 - pdrop) * 60, w, 90, labels[i] if pm < .4 else "", icons[i] if pm < .4 else None,
             a, lit=u > tc[i] + .3, size=40)
    if pm > 0:
        g.glow(960, 440, 300, .18 * pm)
        s = 220 * e_back(pm)
        icon_draw(g, "shield", 960, 440, s, GREEN, pm)
    ah, dh = rise(u, tmg + 0.8)
    g.text("If it holds up there,", 960, 680 + dh, 80, TXT, ah)
    g.text2([("it holds up ", TXT), ("for you.", GREEN)], 960, 775 + dh, 80, ah * prog(u, tmg + 1.2, .3))

def S8(g, u, T, sc):
    r1 = T("thirty minutes", 1.0); r2 = T("honestly", r1 + 1.6)
    r3 = r2 + 1.6; tsp = T("two-week", r3 + 1.6)
    a, dy = rise(u, 0.1)
    card(g, 360, 170 + dy, 1200, 380, a)
    g.text("Let's talk", 960, 230 + dy, 52, TXT2, a, "m")
    for i, (s, t0) in enumerate((("30-minute call", r1), ("Honest fit check", r2), ("No pitch", r3))):
        ai, di = rise(u, t0, 0.5)
        y = 325 + i * 90 + dy + di
        tick_circle(g, 480, y, 26, ai * a, e_back(prog(u, t0, .4)))
        g.text(s, 550, y, 62, TXT, ai * a, "b", "lm")
    a2, d2 = rise(u, T("if it does", tsp - 1.0) - 0.2)
    hit = prog(u, tsp, 0.4)
    g.glow(960, 700, 520, .12 * hit * a2)
    card(g, 360, 590 + d2, 1200, 200, a2, GREEN if hit else BORDER)
    g.line([(520, 690 + d2), (1400, 690 + d2)], GREEN, 5, a2)
    for x, s in ((520, "2-week sprint"), (1400, "Fixed price")):
        g.circ(x, 690 + d2, 16, fill=GREEN, a=a2)
        g.text(s, x, 640 + d2, 38, TXT, a2)

def S9(g, u, T, sc):
    a = prog(u, 0, 0.3)
    g.rect(0, 0, 1920, 1080, 0, fill=DARK, a=a)
    g.glow(960, 400, 560, .16 * a)
    al, dl = rise(u, 0.4)
    g.logo("minsky_logo_white", 960, 400 + dl, 420, al, "Minsky")
    for i, (s, c) in enumerate((("minsky.in", GREEN), ("info@minsky.in", TXT), ("+91 89251 96011", TXT))):
        ai, di = rise(u, 1.2 + i * 0.5, 0.5)
        g.text(s, 960, 620 + i * 100 + di, 54, c, ai, "b")

# ----------------------------------------------------------------- script (spoken = what is sent to ElevenLabs)
SCENES = [
 dict(id="S1", fn=S1, lead=0.3, need=lambda T: 6.5,
      spoken="Ten thousand startups applied for Tamil Nadu government funding. Every application was read by hand.",
      display="Ten thousand startups applied for Tamil Nadu government funding. Every application was read by hand."),
 dict(id="S2", fn=S2, lead=0.5, need=lambda T: 6.5,
      spoken="Passed around on email. Scored on spreadsheets.",
      display="Passed around on email. Scored on spreadsheets."),
 dict(id="S3", fn=S3, lead=0.5, need=lambda T: T("we rebuilt", 6) + 3.4,
      spoken="That's what we walked into at Startup T N. So we didn't bolt a chatbot on top. We rebuilt how the work moves.",
      display="That's what we walked into at StartupTN. So we didn't bolt a chatbot on top. We rebuilt how the work moves."),
 dict(id="S4", fn=S4, lead=0.6, need=lambda T: T("every step", 14) + 4.2,
      spoken="Now AI reads the pitch deck, checks the G S T and tax records, and ranks every startup, with evidence behind each score. And here's the part that matters most: the committee still decides. AI ranks. People decide. Every step is logged.",
      display="Now AI reads the pitch deck, checks the GST and tax records, and ranks every startup, with evidence behind each score. And here's the part that matters most: the committee still decides. AI ranks. People decide. Every step is logged."),
 dict(id="S5", fn=S5, lead=2.1, need=lambda T: T("thirty days", 4) + 3.6,
      spoken="The result? Eighty percent less manual screening. Applications moving thirty days faster.",
      display="The result? Eighty percent less manual screening. Applications moving thirty days faster."),
 dict(id="S6", fn=S6, lead=0.5, need=lambda T: T("more than three", 7) + 4.0,
      spoken="Same engine, different problem. For Fa Me T N, over ten thousand buyer and seller matches, and more than three and a half thousand meetings, planned automatically.",
      display="Same engine, different problem. For FaMeTN, over ten thousand buyer and seller matches, and more than three and a half thousand meetings, planned automatically."),
 dict(id="S7", fn=S7, lead=0.4, need=lambda T: T("if it holds", 6) + 4.0,
      spoken="Government is the hardest place to ship AI. Huge volumes. Public scrutiny. Audits. If it holds up there, it'll hold up in your business.",
      display="Government is the hardest place to ship AI. Huge volumes. Public scrutiny. Audits. If it holds up there, it'll hold up in your business."),
 dict(id="S8", fn=S8, lead=0.4, need=lambda T: T("two-week", 12) + 3.6,
      spoken="If your team still spends its days collecting, checking and forwarding things by hand, let's talk. Thirty minutes. We'll look at where your workflow gets stuck, and tell you honestly whether AI even makes sense. If it does, a two-week, fixed-price sprint maps the whole thing.",
      display="If your team still spends its days collecting, checking and forwarding things by hand, let's talk. Thirty minutes. We'll look at where your workflow gets stuck, and tell you honestly whether AI even makes sense. If it does, a two-week, fixed-price sprint maps the whole thing."),
 dict(id="S9", fn=S9, lead=0.5, need=lambda T: 5.0,
      spoken="Minsky. Details below.", display="Minsky. Details below."),
]

# ----------------------------------------------------------------- timeline (audio lengths, word times, captions)
def ffprobe_len(path):
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path],
                           capture_output=True, text=True)
        return float(r.stdout.strip())
    except Exception:
        return None

def find_vo(i):
    for ext in ("mp3", "wav", "m4a"):
        p = os.path.join(VO_DIR, f"A_s{i:02d}.{ext}")
        if os.path.exists(p): return p
    return None

SENT = re.compile(r"[^.?!]+[.?!]*")

def build_timeline():
    t = 0.0
    for i, sc in enumerate(SCENES, 1):
        text = sc["spoken"]; lead = sc["lead"]
        vo = find_vo(i); sc["vo"] = vo
        js = os.path.join(VO_DIR, f"A_s{i:02d}.json")
        al = None
        if os.path.exists(js):
            try:
                d = json.load(open(js)); al = d.get("alignment") or d.get("normalized_alignment")
            except Exception:
                al = None
        if al and al.get("characters"):
            text = "".join(al["characters"])
            ct = [x + lead for x in al["character_start_times_seconds"]]
            speech_end = al["character_end_times_seconds"][-1] + lead
            if vo:
                speech_end = max(speech_end, (ffprobe_len(vo) or 0) + lead - 0.05)
        else:
            est = len(text.split()) / 2.8 + 0.3 * len(SENT.findall(text))
            if vo:
                est = ffprobe_len(vo) or est
            n = max(1, len(text))
            ct = [lead + est * k / n for k in range(n)]
            speech_end = lead + est
        sc["_text"], sc["_ct"], sc["speech_end"] = text, ct, speech_end
        lo = text.lower()
        def T(phrase, default=1.0, _lo=lo, _ct=ct):
            k = _lo.find(phrase.lower())
            return _ct[k] if k >= 0 else default
        sc["T"] = T
        sc["dur"] = max(speech_end + 0.8, sc["need"](T))
        sc["start"] = t
        t += sc["dur"]
        sc["caps"] = build_caps(sc)
    return t

def build_caps(sc):
    disp = [s.strip() for s in SENT.findall(sc["display"]) if s.strip()]
    text, ct = sc["_text"], sc["_ct"]
    spans = [(m.start() + (len(m.group()) - len(m.group().lstrip())), m.end()) for m in SENT.finditer(text) if m.group().strip()]
    start0, end0 = ct[0], sc["speech_end"]
    if len(spans) == len(disp):
        sents = []
        for k, (a, b) in enumerate(spans):
            s = ct[min(a, len(ct) - 1)]
            e = ct[min(spans[k + 1][0], len(ct) - 1)] if k + 1 < len(spans) else end0 + 0.3
            sents.append((s, e, disp[k]))
    else:
        tot = sum(len(d) for d in disp); cur = start0; sents = []
        for d in disp:
            dd = (end0 - start0) * len(d) / tot
            sents.append((cur, cur + dd, d)); cur += dd
    caps = []
    for s, e, d in sents:
        words, chunks, cur = d.split(), [], ""
        for w in words:
            if cur and len(cur) + len(w) + 1 > 58:
                chunks.append(cur); cur = w
            else:
                cur = (cur + " " + w).strip()
        if cur: chunks.append(cur)
        tot = sum(len(c) for c in chunks); pos = 0
        for c in chunks:
            a = s + (e - s) * pos / tot; pos += len(c)
            b = s + (e - s) * pos / tot
            caps.append((a, b, c))
    return caps

HL = {"eighty", "percent", "thirty", "days", "ten", "thousand", "faster", "less"}
def draw_caption(g, txt, a):
    size = 50
    lines = g.wrap(txt, size, 1500)
    lh = size * 1.28; h = len(lines) * lh + 28; cy = 960
    widest = max(g.tw(l, size) for l in lines)
    g.rect(960 - widest / 2 - 32, cy - h / 2, widest + 64, h, 18, fill=(0, 0, 0), a=.55 * a)
    for i, l in enumerate(lines):
        y = cy - h / 2 + 14 + lh * (i + .5)
        x = 960 - g.tw(l, size) / 2
        for w in l.split():
            key = re.sub(r"\W", "", w.lower())
            c = GREEN if (key in HL or any(ch.isdigit() for ch in key)) else TXT
            g.text(w, x, y, size, c, a, "b", "lm")
            x += g.tw(w + " ", size)

# ----------------------------------------------------------------- sound effects (synthesised) and mix
def _env(n, k): return np.exp(-np.arange(n) / SR * k)
def sfx_wave(name):
    rng = np.random.default_rng(1)
    if name == "tick":
        n = int(.05 * SR); t = np.arange(n) / SR
        return .5 * np.sin(2 * np.pi * 1900 * t) * _env(n, 90)
    if name == "click":
        n = int(.06 * SR); t = np.arange(n) / SR
        return .45 * (np.sin(2 * np.pi * 1200 * t) * _env(n, 70) + .3 * rng.standard_normal(n) * _env(n, 200))
    if name == "thud":
        n = int(.5 * SR); t = np.arange(n) / SR
        return .9 * np.sin(2 * np.pi * (70 - 25 * t) * t) * _env(n, 9)
    if name == "whoosh":
        n = int(.55 * SR); x = rng.standard_normal(n)
        k = np.ones(220) / 220; x = np.convolve(x, k, "same") * 4
        return .5 * x * np.sin(np.pi * np.arange(n) / n) ** 2
    if name == "chime":
        n = int(1.0 * SR); t = np.arange(n) / SR
        return .4 * (np.sin(2 * np.pi * 880 * t) + .6 * np.sin(2 * np.pi * 1320 * t)) * _env(n, 4.5)
    return np.zeros(10)

def sfx_events(sc):
    T, i = sc["T"], sc["id"]
    ev = []
    if i == "S1":
        ev += [(0.4 + k * 0.24, "tick") for k in range(10)] + [(2.8, "thud")]
    if i == "S2":
        ev += [(0.7 + k * 0.8, "whoosh") for k in range(3)]
    if i == "S3":
        ev += [(0.0, "whoosh"), (T("we rebuilt", 6) + 1.4, "chime")]
    if i == "S4":
        n3 = T("ranks every", 4.6)
        ev += [(T("reads the", 1), "click"), (T("checks the", 2.6), "click"), (n3, "click"), (n3 + 1.2, "click"), (n3 + 2.0, "click"),
               (T("committee still", 9), "chime")]
        tl = T("every step", 14) - 0.6
        ev += [(tl + 0.9 + k * 0.7, "tick") for k in range(4)]
    if i == "S5":
        t80 = T("eighty", 2); t30 = T("thirty days", t80 + 2)
        ev += [(t80 + k * 0.2, "tick") for k in range(5)] + [(t80 + 1.2, "thud")]
        ev += [(t30 + k * 0.2, "tick") for k in range(5)] + [(t30 + 1.2, "thud")]
    if i == "S6":
        _, times = _s6_lines()
        ev += [(t + 0.3, "tick") for t in times[::2]] + [(T("ten thousand", 3.5) + 1.2, "chime"), (T("more than three", 6.5) + 1.2, "chime")]
    if i == "S7":
        ev += [(T("huge volumes", 2.6), "thud"), (T("public scrutiny", 3.4), "thud"), (T("audits", 4.2), "thud"), (T("if it holds", 5) + .6, "chime")]
    if i == "S8":
        r1 = T("thirty minutes", 1); r2 = T("honestly", r1 + 1.6)
        ev += [(r1, "tick"), (r2, "tick"), (r2 + 1.6, "tick"), (T("two-week", r2 + 3.2), "chime")]
    return ev

def decode(path, dur):
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-f", "f32le", "-ar", str(SR), "-ac", "1", "-"], capture_output=True)
    return np.frombuffer(r.stdout, dtype=np.float32)

def mix_audio(total, path):
    n = int(total * SR) + SR
    sfx = np.zeros(n, np.float32); vo = np.zeros(n, np.float32)
    for sc in SCENES:
        for t, name in sfx_events(sc):
            w = sfx_wave(name); s = int((sc["start"] + t) * SR)
            if 0 <= s < n: sfx[s:s + len(w)] += w[:n - s] * 0.5
        if sc["vo"]:
            a = decode(sc["vo"], sc["dur"]); s = int((sc["start"] + sc["lead"]) * SR)
            vo[s:s + len(a)] += a[:max(0, n - s)]
    music = np.zeros(n, np.float32)
    mp = next((p for p in (os.path.join(ASSETS, "music.mp3"), os.path.join(ASSETS, "music.wav")) if os.path.exists(p)), None)
    if mp:
        m = decode(mp, total)
        if len(m) > 0:
            m = np.tile(m, int(math.ceil(n / len(m))))[:n]
            fi, fo = np.minimum(1, np.arange(n) / (SR * 1.5)), np.minimum(1, (n - np.arange(n)) / (SR * 3))
            env = np.convolve(np.abs(vo), np.ones(int(SR * .35)) / (SR * .35), "same")
            duck = 1 - 0.65 * np.clip(env / 0.05, 0, 1)
            duck = np.convolve(duck, np.ones(int(SR * .2)) / (SR * .2), "same")
            music = m * fi * fo * duck * 0.12
    mix = vo + sfx + music
    pk = np.max(np.abs(mix)) or 1
    mix = mix / pk * 0.89 if pk > 0.89 else mix
    pcm = (np.clip(mix, -1, 1) * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())

# ----------------------------------------------------------------- rendering
CFG = {}
def init(cfg):
    CFG.update(cfg)

def locate(t):
    for sc in SCENES:
        if t < sc["start"] + sc["dur"]:
            return sc, max(0.0, t - sc["start"])
    return SCENES[-1], SCENES[-1]["dur"]

def render_scene_frame(sc, u, cfg=None):
    cfg = cfg or CFG
    R = cfg["width"] / 1920 * cfg["ss"]
    t = sc["start"] + u
    bg = make_bg(t, R)
    im = bg.copy()
    g = G(im, R)
    sc["fn"](g, u, sc["T"], sc)
    env = min(prog(u, 0, 0.25), 1 - prog(u, sc["dur"] - 0.3, 0.3))
    if env < 1:
        im = Image.blend(bg, im, clamp(env))
    gc = G(im, R)
    for a, b, txt in sc["caps"]:
        if a <= u < b + 0.05:
            draw_caption(gc, txt, min(prog(u, a, 0.15), 1 - prog(u, b - 0.05, 0.1)))
            break
    return im.reduce(cfg["ss"]) if cfg["ss"] > 1 else im

def render_idx(idx):
    t = idx / CFG["fps"]
    sc, u = locate(t)
    return render_scene_frame(sc, u).tobytes()

def encode(frames_iter, w, h, fps, path):
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", str(fps), "-i", "-",
           "-c:v", "libx264", "-preset", "medium", "-crf", "16", "-pix_fmt", "yuv420p", path]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for k, fr in enumerate(frames_iter):
        p.stdin.write(fr)
        if k % 60 == 0: print(f"  frame {k}", end="\r", flush=True)
    p.stdin.close(); p.wait()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--preview", action="store_true")
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--ss", type=int, default=2)
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument("--stills", action="store_true")
    ap.add_argument("--frame", nargs=2, metavar=("SCENE", "SECONDS"))
    ap.add_argument("--scene")
    a = ap.parse_args()
    if a.preview: a.width, a.fps, a.ss = 960, 15, 1
    os.makedirs(OUT, exist_ok=True)
    total = build_timeline()
    cfg = dict(width=a.width, fps=a.fps, ss=a.ss)
    init(cfg)
    h = int(a.width * 9 / 16)
    print(f"Timeline: {total:.1f} s, " + ", ".join(f"{s['id']}={s['dur']:.1f}" for s in SCENES))
    if a.frame:
        sc = next(s for s in SCENES if s["id"] == a.frame[0].upper())
        p = os.path.join(OUT, f"frame_{sc['id']}_{a.frame[1]}.png")
        render_scene_frame(sc, float(a.frame[1]), cfg).save(p); print(p); return
    if a.stills:
        d = os.path.join(OUT, "stills"); os.makedirs(d, exist_ok=True)
        for sc in SCENES:
            for k, f in enumerate((0.3, 0.6, 0.93)):
                render_scene_frame(sc, sc["dur"] * f, cfg).save(os.path.join(d, f"{sc['id']}_{k}.png"))
        print("stills ->", d); return
    if a.scene:
        sc = next(s for s in SCENES if s["id"] == a.scene.upper())
        n = int(sc["dur"] * a.fps)
        encode((render_scene_frame(sc, i / a.fps, cfg).tobytes() for i in range(n)), a.width, h, a.fps, os.path.join(OUT, f"scene_{sc['id']}.mp4"))
        print("\nscene ->", os.path.join(OUT, f"scene_{sc['id']}.mp4")); return
    n = int(math.ceil(total * a.fps))
    vid = os.path.join(OUT, "video_silent.mp4")
    print(f"Rendering {n} frames at {a.width}x{h}, ss={a.ss}, workers={a.workers}")
    if a.workers > 1:
        with Pool(a.workers, initializer=init, initargs=(cfg,)) as pool:
            encode(pool.imap(render_idx, range(n), chunksize=6), a.width, h, a.fps, vid)
    else:
        encode((render_idx(i) for i in range(n)), a.width, h, a.fps, vid)
    wav = os.path.join(OUT, "mix.wav"); mix_audio(total, wav)
    final = os.path.join(OUT, "minsky_90s_16x9.mp4" if not a.preview else "minsky_preview.mp4")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", vid, "-i", wav, "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                    "-movflags", "+faststart", "-shortest", final], check=True)
    print("\nDone ->", final)

# timeline is built at import so worker processes (and gen_voiceover.py) share it
build_timeline()

if __name__ == "__main__":
    main()
