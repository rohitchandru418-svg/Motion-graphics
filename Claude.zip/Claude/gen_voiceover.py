#!/usr/bin/env python3
"""
Generate one ElevenLabs voiceover file per scene, plus word-level timestamps.
  export ELEVENLABS_API_KEY=...        (never paste the key into code)
  export ELEVENLABS_VOICE_ID=...       (voice id from your ElevenLabs library)
  export ELEVENLABS_MODEL=eleven_multilingual_v2   (optional; use the best model on your plan)
  python gen_voiceover.py              (all scenes)   |   python gen_voiceover.py S4 S5   (only some)
Writes vo/A_s01.mp3 + vo/A_s01.json ... which build_minsky_A.py picks up automatically.
Check the endpoint/fields against the current ElevenLabs API docs if a call fails.
"""
import os, sys, json, base64, urllib.request, urllib.error
from build_minsky_A import SCENES, VO_DIR

key = os.environ.get("ELEVENLABS_API_KEY"); voice = os.environ.get("ELEVENLABS_VOICE_ID")
model = os.environ.get("ELEVENLABS_MODEL", "eleven_multilingual_v2")
if not key or not voice:
    sys.exit("Set ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID first.")
only = {a.upper() for a in sys.argv[1:]}
os.makedirs(VO_DIR, exist_ok=True)
SETTINGS = {"stability": 0.45, "similarity_boost": 0.75, "style": 0.1, "use_speaker_boost": True}  # tune by ear

for i, sc in enumerate(SCENES, 1):
    if only and sc["id"] not in only:
        continue
    body = json.dumps({"text": sc["spoken"], "model_id": model, "voice_settings": SETTINGS}).encode()
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice}/with-timestamps?output_format=mp3_44100_128"
    req = urllib.request.Request(url, data=body, headers={"xi-api-key": key, "Content-Type": "application/json"})
    try:
        data = json.loads(urllib.request.urlopen(req, timeout=120).read())
    except urllib.error.HTTPError as e:
        sys.exit(f"{sc['id']} failed: {e.code} {e.read()[:300]}")
    open(os.path.join(VO_DIR, f"A_s{i:02d}.mp3"), "wb").write(base64.b64decode(data["audio_base64"]))
    json.dump({"alignment": data.get("alignment"), "normalized_alignment": data.get("normalized_alignment")},
              open(os.path.join(VO_DIR, f"A_s{i:02d}.json"), "w"))
    print("saved", sc["id"])
