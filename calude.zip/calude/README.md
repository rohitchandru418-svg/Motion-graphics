# Minsky launch video: Version A (LinkedIn, 16:9)

Code-built SaaS motion graphic. No people on screen. Pillow draws frames, ffmpeg encodes, numpy mixes audio.

## Run
    pip install pillow numpy           # optional: pip install cairosvg  (for .svg logos)
    python build_minsky_A.py --stills  # 3 PNG stills per scene in out/stills (check the look first)
    python build_minsky_A.py --preview # fast 960x540 test render
    python build_minsky_A.py           # final 1920x1080, 30 fps, 2x supersampled -> out/minsky_90s_16x9.mp4
Needs ffmpeg + ffprobe on PATH. Python 3.9+.

## Add your assets (all optional, placeholders are drawn if missing)
    assets/startuptn_logo.png (or .svg)    assets/fametn_logo.png (or .svg)
    assets/minsky_logo_white.png (or .svg) assets/music.mp3
    assets/fonts/Inter-Bold.ttf  Inter-Medium.ttf   (brand font; falls back to DejaVu/Arial)
Logos must be transparent and readable on a dark background. Set exact brand colours at the top of build_minsky_A.py (BG, GREEN).

## Voiceover (ElevenLabs)
    export ELEVENLABS_API_KEY=...  ELEVENLABS_VOICE_ID=...
    python gen_voiceover.py        # writes vo/A_s01.mp3 + .json (word timestamps) for each scene
    python build_minsky_A.py       # re-times every animation to the real spoken words
Without vo/ files the video renders as a silent draft using estimated timings (+ synthesised sound effects, + music if present).
To regenerate one line: python gen_voiceover.py S4

## How timing works
Every animation is keyed to a phrase in the spoken text, e.g. T("eighty"). Real word times come from vo/*.json; otherwise an estimate is used. Scene length = max(speech length + 0.8 s, time needed for the last animation). Expect about 95 to 105 s total with a natural read, not exactly 90 s. To tighten, shorten the script text or the `need` values in SCENES.

## Editing
- Copy/numbers: SCENES list (spoken = text sent to ElevenLabs, display = captions).
- Look of one scene: its function S1..S9. Check with: python build_minsky_A.py --frame S4 12.5
- Re-render one scene only: python build_minsky_A.py --scene S4
- Sound effects are simple synthesised ticks/thuds/chimes (sfx_events); replace with your own by editing mix_audio.

## Motion-graphic layer (v2)
- Kinetic type: headlines spring in letter by letter; "AI ranks. People decide." slams in word by word.
- Impact effects: shockwave rings and particle bursts when counters land, nodes light, the committee tick appears and the shield forms; numbers punch-scale on landing.
- Camera: every scene starts slightly zoomed and settles, then pushes in slowly with a small drift.
- Transitions: three diagonal bars (green, panel, background) wipe between scenes.
- Living background: parallax dot grid, drifting glow blobs and orbiting rings; idle floating on cards.
- Real motion blur: temporal sub-frames averaged per frame. Default 3 in the final render (--mb 1 to turn off, --mb 5 for heavier blur). It multiplies render time by the sub-frame count.
